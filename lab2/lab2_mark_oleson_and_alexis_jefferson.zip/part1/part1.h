// Lab 2 - Multithreaded Programming and Synchronization
// Part 1: Simple Multithreaded Programming
// Mark Oleson & Alexis Jefferson
// COP4610 Operating Systems

#ifndef PART1_H
#define PART1_H

void printUsage();
void printInputError();

void SimpleThread(void *args);

#endif
