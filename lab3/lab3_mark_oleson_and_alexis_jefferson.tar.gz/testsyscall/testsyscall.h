#include <linux/unistd.h>

#define __NR_get_slob_amt_claimed 343
#define __NR_get_slob_amt_free 344
